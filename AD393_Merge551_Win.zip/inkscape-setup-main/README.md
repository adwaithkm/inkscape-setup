# inkscape-setup
AI tool to draw image [PLOT BOT]
